round2 <- function(x){
  ## Round values to 2 decimal places
  round(x, 2)
}

